$(document).ready(function() {
    $("#accordion").accordion();
    $("#resizable").resizable({
        animate: true,
        aspectRatio: 16 / 9,
        ghost: true
    });
    $("#button").on("click", function() {
        $("#p5").dialog();

    });
    $(function() {
        $("#resizable").draggable();
    });

});
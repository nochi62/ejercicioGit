package votaciones;

public class Huevo {

}

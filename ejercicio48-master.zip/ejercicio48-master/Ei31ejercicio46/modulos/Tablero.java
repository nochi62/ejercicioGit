package votaciones;

import java.util.ArrayList;
import java.util.Random;

public class Tablero {
	String[][] arrayCarro;
	ArrayList listaHuevo;
	String[][] tablero;
	int i = 0;
	int j = 0;
	int fila = 0;
	int columna = 0;
	int pos = 0;
	int h = 0;
	int k = 0;
	int puntaje = 0;
	
	Random r = new Random();

	public void setTablero() {
		i = 0;
		j = 0;

		String[][] tablero = new String[15][15];

//		System.out.println("aqui voy");
		for (i = 0; i <= 14; i++) {
			for (j = 0; j <= 14; j++) {
				tablero[i][j] = "X";
			}
		}
	}

////////////////////////////////////////////////////////////////////////
	public void getTablero() {
		i = 0;
		j = 0;

		for (int x = 0; x < tablero.length; x++) {
			System.out.print("[");
			for (int y = 0; y < tablero[x].length; y++) {
				System.out.print(tablero[x][y]);
				if (y != tablero[x].length - 1)
					System.out.print("] [");
			}
			System.out.println("]");
		}
	}

//////////////////////////////////////////////////////////////////////
//		Metodo Crear Carro
//		
	public void crearCarro() {
		String[][] arrayCarro = new String[18][3];
		
		UsoCarro usocarro = new UsoCarro();
		
//		crear Kromi
		
//
		for (h = 0; h <= 2; h++) {
			do {
				fila = 0;
				columna = 0;
				pos = 0;
				h = 0;

				fila = r.nextInt(13) + 1;
				columna = r.nextInt(13) + 1;
				System.out.print("coordenada : " + fila + " " + columna);

				if (fila < 14) {
					if (tablero[fila][columna] == "X" && tablero[fila + 1][columna] == "X"
							&& tablero[fila + 2][columna] == "X") {
						tablero[fila][columna] = "K";
						tablero[fila + 1][columna] = "K";
						tablero[fila + 2][columna] = "K";
						pos = 1;
						
					}
				}
			} while (pos == 0);
			arrayCarro[k][0] =  "K";
			arrayCarro[k][1] =  Integer.toString(fila);
			arrayCarro[k][2] =  Integer.toString(columna);
			arrayCarro[k][3] =  Integer.toString(fila+1);
			arrayCarro[k][4] =  Integer.toString(columna);
			arrayCarro[k][5] =  Integer.toString(fila+2);
			arrayCarro[k][6] =  Integer.toString(columna);
			k = k +1;
		}

//		crear Caguano
//

		for (h = 0; h <= 4; h++) {
			fila = 0;
			columna = 0;
			pos = 0;
			h = 0;

			fila = r.nextInt(13) + 1;
			columna = r.nextInt(13) + 1;
			System.out.print("coordenada : " + fila + " " + columna);

			do {
				fila = r.nextInt(13) + 1;
				columna = r.nextInt(13) + 1;
				System.out.print("coordenada : " + fila + " " + columna);

				if (columna < 14) {
					if (tablero[fila][columna] == "X" && tablero[fila][columna + 1] == "X") {
						tablero[fila][columna] = "C";
						tablero[fila][columna + 1] = "C";
						pos = 1;
					}
				}
			} while (pos == 0);
			arrayCarro[k][0] =  "C";
			arrayCarro[k][1] =  Integer.toString(fila);
			arrayCarro[k][2] =  Integer.toString(columna);
			arrayCarro[k][3] =  Integer.toString(fila);
			arrayCarro[k][4] =  Integer.toString(columna+1);
			k = k +1;
		}

//		crear Trupalla
//

		for (h = 0; h <= 9; h++) {
			do {
				int fila = 0;
				int columna = 0;
				int pos = 0;
				h = 0;

				fila = r.nextInt(13) + 1;
				columna = r.nextInt(13) + 1;
				System.out.print("coordenada : " + fila + " " + columna);

				if (fila < 15) {
					if (tablero[fila][columna] == "X") {
						tablero[fila][columna] = "T";
						pos = 1;
					}
				}
			} while (pos == 0);
			arrayCarro[k][0] =  "T";
			arrayCarro[k][1] =  Integer.toString(fila);
			arrayCarro[k][2] =  Integer.toString(columna);
			k = k +1;
		}
	}

//////////////////////////////////////////////////////////////////////
	public class subCarros extends UsoCarros {
		private String IdProfesor;

		// Constructor de la subclase: incluimos como par�metros al menos los del
		// constructor de la superclase
		public subCarros(String nombre, String apellidos, int edad) {
			super(nombre, apellidos, edad);
			IdProfesor = "Unknown";
		}

		// M�todos espec�ficos de la subclase
		public void setIdProfesor(String IdProfesor) {
			this.IdProfesor = IdProfesor;
		}

		public String getIdProfesor() {
			return IdProfesor;
		}

		public void mostrarNombreApellidosYCarnet() {
			System.out.println("Profesor de nombre: " + getNombre() + " " + getApellidos() + " con Id de profesor: "
					+ getIdProfesor());
		}
	}

//////////////////////////////////////////////////////////////////////
//	Metodo Lanzar Huevo
//
	public void lanzar_huevo() {
		int fila = 0;
		int columna = 0;
		int pos = 0;
		
		Huevo huevo = new Huevo();

		fila = r.nextInt(13) + 1;
		columna = r.nextInt(13) + 1;
		System.out.print("fila : " + fila+" "+columna);
		
		huevo.fila = fila;
		huevo.columna = columna;

		switch (tablero[fila][columna]) {
		case "K":
			puntaje = puntaje + 3;
			tablero[fila][columna] = "H";
			break;

		case "C":
			puntaje = puntaje + 2;
			tablero[fila][columna] = "H";
			break;

		case "T":
			puntaje = puntaje + 1;
			tablero[fila][columna] = "H";
			break;

		default:
			puntaje = puntaje + 0;
			break;
		}
		huevo.puntaje = puntaje;

	}

//////////////////////////////////////////////////////////////////////
//	Metodo Mostrar Matriz
//
	public void mostrarMatriz() {
		i = 0;
		j = 0;

		for (int x = 0; x < tablero.length; x++) {
			System.out.print("[");
			for (int y = 0; y < tablero[x].length; y++) {
				System.out.print(tablero[x][y]);
				if (y != tablero[x].length - 1)
					System.out.print("] [");
			}
			System.out.println("]");
		}
	}
//////////////////////////////////////////////////////////////////////
//	Metodo Calcular Puntaje
//

	public void calcularPuntaje() {

		System.out.println("Puntaje acumulado ...: "+puntaje);
	}

}

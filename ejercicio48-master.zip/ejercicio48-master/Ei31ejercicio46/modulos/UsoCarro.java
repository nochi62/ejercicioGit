package votaciones;

public class UsoCarro {

}

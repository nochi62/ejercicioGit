package votaciones;

//import java.lang.reflect.Array;
import java.util.Random;

public class crearCarro(tablero[][]) {

	public crearCarro(tablero[][]) {
	

	public void ubicaKromi(String tablero[][]) {
		int fila = 0;
		int columna = 0;
		int pos = 0; // pos = 0 indica que ubicacion est� ocupada
		Random r = new Random();

		do {
			fila = r.nextInt(13) + 1; // Entre 0 y 5, m�s 1.
			System.out.print("fila : " + fila);

			columna = r.nextInt(13) + 1; // Entre 0 y 5, m�s 1.
			System.out.print("columna: " + columna);

			if (fila < 14) {
				if (tablero[fila][columna] == "X" && tablero[fila + 1][columna] == "X"
						&& tablero[fila + 2][columna] == "X") {
					tablero[fila][columna] = "K";
					tablero[fila + 1][columna] = "K";
					tablero[fila + 2][columna] = "K";
					pos = 1;
				}
			}
		} while (pos == 0);
	}

	public void ubicaCaguano(String tablero[][]) {
		int fila = 0;
		int columna = 0;
		int pos = 0;
		
		Random r = new Random();

		fila  = r.nextInt(13)+1;
		System.out.print("fila : "+fila);
		
		columna  = r.nextInt(13)+1;
		System.out.print("columna: "+columna);
		
		do {
			fila  = r.nextInt(13)+1; 
			System.out.print("fila : "+fila);
			
			columna  = r.nextInt(13)+1;  // Entre 0 y 5, m�s 1.
			System.out.print("columna: "+columna);
			
			if (fila < 14) {
				if (tablero[fila][columna] == "X" 
					&& tablero[fila+1][columna] == "X" 
					&& tablero[fila+2][columna] == "X") {
					tablero[fila][columna] = "K";
					tablero[fila+1][columna] = "K";
					tablero[fila+2][columna] = "K";
					pos = 1;
					}
				}
			}while (pos == 0);

	public void ubicaTrupalla(tablero[][]) {
		int fila = 0;
		int columna = 0;
		int pos = 0;
		
		Random r = new Random();

		fila  = r.nextInt(13)+1;  // Entre 0 y 5, m�s 1.
		System.out.print("fila : "+fila);
		
		columna  = r.nextInt(13)+1;  // Entre 0 y 5, m�s 1.
		System.out.print("columna: "+columna);
		
		do {
			fila  = r.nextInt(13)+1; 
			System.out.print("fila : "+fila);
			
			columna  = r.nextInt(13)+1;  // Entre 0 y 5, m�s 1.
			System.out.print("columna: "+columna);
			
			if (fila < 14) {
				if (tablero[fila][columna] == "X" 
					&& tablero[fila+1][columna] == "X" 
					&& tablero[fila+2][columna] == "X") {
					tablero[fila][columna] = "K";
					tablero[fila+1][columna] = "K";
					tablero[fila+2][columna] = "K";
					pos = 1;
					}
				}
			} while (pos == 0);
		}
		
	}
}

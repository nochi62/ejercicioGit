package votaciones;

public class otros {

	
	public void crearTablero() {
		int i = 0;
		int j = 0;
		
		System.out.println("aqui voy");
		for (i = 0; i <= 14; i++) {
			for (j = 0; j <= 14; j++) {
				tablero[i][j] = "X";
			}
		}
	}
	
	public void getTablero() {
		i = 0;
		j = 0;
		
		for (int x=0; x < tablero.length; x++) {
			  System.out.print("[");
			  for (int y=0; y < tablero[x].length; y++) {
			    System.out.print (tablero[x][y]);
			    if (y!=tablero[x].length-1) System.out.print("] [");
			  }
			  System.out.println("]");
			}
	}

	
	===========================================================
			// Declaraci�n de un ArrayList de "String". Puede ser de cualquier otro Elemento u Objeto (float, Boolean, Object, ...)
			ArrayList<String> nombreArrayList = new ArrayList<String>();
			// A�ade el elemento al ArrayList
			nombreArrayList.add("Elemento");
			// A�ade el elemento al ArrayList en la posici�n 'n'
			nombreArrayList.add(n, "Elemento 2");
			// Devuelve el numero de elementos del ArrayList
			nombreArrayList.size();
			// Devuelve el elemento que esta en la posici�n '2' del ArrayList
			nombreArrayList.get(2);
			// Comprueba se existe del elemento ('Elemento') que se le pasa como parametro
			nombreArrayList.contains("Elemento");
			// Devuelve la posici�n de la primera ocurrencia ('Elemento') en el ArrayList  
			nombreArrayList.indexOf("Elemento");
			// Devuelve la posici�n de la �ltima ocurrencia ('Elemento') en el ArrayList   
			nombreArrayList.lastIndexOf("Elemento");
			// Borra el elemento de la posici�n '5' del ArrayList   
			nombreArrayList.remove(5); 
			// Borra la primera ocurrencia del 'Elemento' que se le pasa como parametro.  
			nombreArrayList.remove("Elemento");
			//Borra todos los elementos de ArrayList   
			nombreArrayList.clear();
			// Devuelve True si el ArrayList esta vacio. Sino Devuelve False   
			nombreArrayList.isEmpty();  
			// Copiar un ArrayList 
			ArrayList arrayListCopia = (ArrayList) nombreArrayList.clone();  
			// Pasa el ArrayList a un Array 
			Object[] array = nombreArrayList.toArray();  
			
			=====================================================
					

					//C�digo de la clase profesor, subclase de la clase Persona ejemplo aprenderaprogramar.com

					public class subCarros extends Carros {

					    //Campos espec�ficos de la subclase.

					    private String IdProfesor;

					    //Constructor de la subclase: incluimos como par�metros al menos los del constructor de la superclase

					    public subCarros(String nombre, String apellidos, int edad) {
					        super(nombre, apellidos, edad);
					        IdProfesor = "Unknown";   } //Cierre del constructor

					    //M�todos espec�ficos de la subclase
					    public void setIdProfesor (String IdProfesor) { this.IdProfesor = IdProfesor;   }
					    public String getIdProfesor () { return IdProfesor;   }
					    public void mostrarNombreApellidosYCarnet() {
				        System.out.println ("Profesor de nombre: " + getNombre() + " " +  getApellidos() +
					         " con Id de profesor: " + getIdProfesor() ); }
					}
							
				}
}

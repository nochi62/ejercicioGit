package votaciones;

//import Tablero;

public class principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Tablero llamada5 = new Tablero();
		
		llamada5.crearTablero();
		
		llamada5.getTablero();
		
		crearCarro llamada6 = new crearCarro();
		
		llamada6.ubicaKromi(tablero[][]);
		llamada6.ubicaCaguano(tablero[][]);
		llamada6.ubicaTrupalla(tablero[][]);
		
		
	}

}
